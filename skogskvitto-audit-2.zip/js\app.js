/**
 * SkogsKvitto — bundled client JS.
 *
 * Strategy:
 *   - Most interactivity lives in Alpine components defined here.
 *   - One global helper (window.applyCorrection) exposed for templates that
 *     need to apply OCR-correction suggestions into the scan-review form.
 *
 * Loaded once via base.html. No per-page scripts.
 */

(function () {
  "use strict";

  // ---------------------------------------------------------------------------
  // Alpine components — registered before Alpine starts
  // ---------------------------------------------------------------------------

  document.addEventListener("alpine:init", () => {
    /**
     * cookieBanner — shows the cookie banner until the user accepts.
     * Persists the choice via localStorage (degrades gracefully).
     */
    Alpine.data("cookieBanner", () => ({
      show: false,

      init() {
        let consent = null;
        try {
          consent = window.localStorage.getItem("cookie_consent");
        } catch (err) {
          consent = null;
        }
        this.show = consent !== "necessary";
      },

      accept() {
        try {
          window.localStorage.setItem("cookie_consent", "necessary");
        } catch (err) {
          // ignore — private mode or storage unavailable
        }
        this.show = false;
      },
    }));

    /**
     * receiptUpload — handles file selection in the scan upload form.
     * Reveals an image preview and the captured file name.
     */
    Alpine.data("receiptUpload", () => ({
      previewUrl: "",
      fileName: "",
      _objectUrl: null,

      onFileChange(event) {
        const target = event.target;
        if (!(target instanceof HTMLInputElement)) {
          return;
        }
        const file = target.files && target.files[0];
        if (!file) {
          return;
        }
        this._revokeObjectUrl();
        const url = URL.createObjectURL(file);
        this._objectUrl = url;
        this.previewUrl = url;
        this.fileName = file.name;
      },

      _revokeObjectUrl() {
        if (this._objectUrl) {
          URL.revokeObjectURL(this._objectUrl);
          this._objectUrl = null;
        }
      },

      destroy() {
        this._revokeObjectUrl();
      },
    }));

    /**
     * thumbnailPreload — primes the browser cache with kassabok thumbnails
     * when the user hovers/focuses the Kassabok tile on the overview.
     *
     * Reads URLs from <span data-url="…"> children inside x-ref="preloadData"
     * and injects <link rel="preload" as="image"> into the document head.
     *
     * Runs at most once per page (the .once modifier on @mouseenter / @focus
     * is belt-and-suspenders to the internal `done` flag).
     */
    Alpine.data("thumbnailPreload", () => ({
      done: false,

      preload() {
        if (this.done) return;
        this.done = true;

        const root = this.$refs.preloadData;
        if (!(root instanceof HTMLElement)) return;

        const urls = Array.from(root.querySelectorAll("[data-url]"))
          .map((el) => el.getAttribute("data-url"))
          .filter((url) => typeof url === "string" && url.length > 0);

        if (urls.length === 0) return;

        const frag = document.createDocumentFragment();
        for (const url of urls) {
          const link = document.createElement("link");
          link.rel = "preload";
          link.as = "image";
          link.href = url;
          // Hint to the browser: don't compete with critical resources
          link.setAttribute("fetchpriority", "low");
          frag.appendChild(link);
        }
        document.head.appendChild(frag);
      },
    }));
  });

  // ---------------------------------------------------------------------------
  // Global helpers (used from inline @click handlers in correction suggestions)
  // ---------------------------------------------------------------------------

  /**
   * Apply an OCR correction suggestion into the scan-review form.
   * Called from correction_suggestion.html via Alpine @click.
   */
  window.applyCorrection = function (suggestion) {
    if (!suggestion || typeof suggestion !== "object") {
      return;
    }

    if (suggestion.totalAmount) {
      const amountInput = document.getElementById("total_amount");
      if (amountInput instanceof HTMLInputElement) {
        amountInput.value = suggestion.totalAmount;
      }
    }

    if (suggestion.category) {
      const categoryInput = document.getElementById("category");
      if (categoryInput instanceof HTMLInputElement) {
        categoryInput.value = suggestion.category;
      }
    }
  };
})();